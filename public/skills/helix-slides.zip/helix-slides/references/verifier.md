# Verifier (Phase 3) — `scripts/verify.mjs`

Static + headless consistency check for a generated deck. The goal: **every
project rule is followed and nothing looks broken** before a deck is delivered.

```
node scripts/verify.mjs <deck.html> [--no-headless] [--json]
```

- Exit code **1** if any **error** finding, else **0** (wire into CI / pre-delivery).
- `--no-headless` skips the browser pass (static only — fast, no dependencies).
- `--json` prints `{ counts, findings }` for tooling.

Rule truth lives in [`brand-tokens.md`](brand-tokens.md), [`../lib/themes.json`](../lib/themes.json),
and [`../lib/rules.json`](../lib/rules.json). The verifier reads the deck's own
embedded `deck-model`, `theme-config`, and `signal-rules`, so it checks the deck
exactly as it will render.

## Severities

| Severity | Meaning |
|---|---|
| `error` (✗) | Breaks a hard rule or the deck. Fails the run (exit 1). |
| `warn` (▲) | Violates a design rule or a likely-overflow heuristic. Review. |
| `info` (·) | Advisory (e.g. add a data source; headless skipped). |

## Pass 1 — static checks

| Rule id | Severity | Checks |
|---|---|---|
| `model` / `schema` | error | Deck has slides; each slide has `id` + `theme`; duplicate ids (warn). |
| `theme-exists` | error | `slide.theme` and any `item.theme` exist in `themes.json`. |
| `canvas-card-combo` | error | Card fill is permitted on its canvas per `themes.matrix` (incl. per-item overrides on the slide canvas). |
| `asset-ref` | error | Every `image.ref` (slide + item) resolves in `assets{}`. |
| `font-usage` | error/warn | Inter **and** Budget Greet Narrow `@font-face` are embedded; no stray families (no serif/mono). |
| `logo-variant` | error/warn | Valid enum; explicit override matches the surface tone (black on light/teal, green on black). Image cards may flip per-image (not flagged). |
| `label-placement` | error/warn | Label = chip. **Error:** on first slide or opening slide. **Warn:** on image card, quote, data, or items-only (top-aligned) — use a subtitle there. |
| `gray-usage` | error | Gray is never a standalone full-width card (secondary column/row only). |
| `data-cards-2x2` | warn | A manual single-row layout for exactly 4 cards (auto layout already does 2×2). |
| `data-source` | warn/info | Data slides need a `Source:` line in presenter notes; metric-number slides get an advisory. |
| `opening-slide` | error/warn | Opening caption present; **Status mandatory** (error), Author (warn). Date auto-stamped. |
| `overflow-heuristic` | warn | Estimated content height (from `rules.json.contentFitting`) exceeds the card slot. Approximate — see headless pass for exact. |

## Pass 2 — headless overflow scan

If `puppeteer` is importable, the deck is rendered at **1920×1080** and each slide
is shown in turn. For every card it measures the real `.content` height against
the card's available height (client height minus padding) and checks that any
`.data-table-wrap` fits inside its card. Real overflow → `overflow` (warn) with
exact pixel figures.

If `puppeteer` is **not** installed, the pass is skipped with an info note and an
install hint (`npm i -D puppeteer`) — the verifier stays self-contained and the
static pass still runs. The layout mirror in `verify.mjs` (`detectSignals` /
`resolveLayout` / `normCols` / `isMetric`) is kept in sync with `lib/render.js`;
if the renderer's layout logic changes, update both.
