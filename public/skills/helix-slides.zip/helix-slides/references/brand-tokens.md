# Budget Thuis — brand truth & "what to use when"

Single source of brand facts for this skill. Values trace to the reference
design system (`budget-thuis-design`). The runtime reads colours from
`lib/themes.json`; this file is the human-readable rationale + usage guide.

## Colours (the only ones a deck uses)

| Token | Hex | Role |
|---|---|---|
| Mint 500 | `#00d780` | Primary brand. Mint card, chip, accent bar. |
| Teal 500 | `#029b77` | Deep brand bed. Teal canvas / teal card. |
| Screen | `#fafafa` | Light page canvas (gray-50). |
| Black/Ink | `#242424` | Dark canvas + dark card (gray-850). |
| Gray card | `#efefef` | Light neutral card (gray-100). |
| White | `#ffffff` | White card (gray-0). |
| Text dark | `#242424` / `#000` | Body / heading on light surfaces. |
| Text light | `#fafafa` / `#fff` | Body / heading on dark surfaces. |

No gradients. Flat fills only. Two greens carry the brand; everything else neutral.

### Text colour (global rule)

**Text is black on every surface** — including teal cards (background teal, text
black). The **only** exception: on **black / ink-black** surfaces text is white or
light. (Teal is treated as a light-tone surface for both text and logo.)

### Gray usage

Gray (`#efefef`) is a **secondary** colour only:
- **Not allowed** as the background of a single full-width / standalone main card
  on a white (screen) slide. A standalone main card never uses gray.
- **Allowed** as a secondary column or row alongside other elements
  (multi-column grids, two-column layouts). The `screen-gray` theme is for that
  secondary use, never a lone full-width card.

### Colour variety — black / ink surfaces

Black / ink-black card surfaces are a valid, intended combination — use them
**occasionally and on purpose**, not as a last resort. Distribute colour variety
across a deck intentionally; do not default every card to white or teal.

## Type

- **Headings — `Budget Greet Narrow` Bold, UPPERCASE** (applied via `text-transform`, never typed in caps). 80–128px on the 1920×1080 canvas. This is the "Greet" face.
- **Body / subtitle / chrome — `Inter`.** Regular (400) for body & subtitle, Medium (500)/SemiBold (600) for emphasis, Bold (700) for table heads & chips.
- **No third family.** No serif, no mono.
- Type scale (canvas px): 128 / 96 / 80 / 64 / 48 / 32.

### What weight to use when
| Use | Family / weight |
|---|---|
| Slide title (h1/h2) | Greet Bold, uppercase |
| Subtitle | Inter Regular |
| Body paragraph | Inter Regular |
| Bullets | Inter Regular |
| Emphasis inside body | Inter SemiBold |
| Table header row | Inter Bold |
| Table body cell | Inter Regular (first column SemiBold) |
| Chip / label | Greet Bold, uppercase |

## Surfaces — canvas vs card

The **canvas** is the backmost layer (the 32px ring colour). **Content never sits
on the canvas** — it always lives inside a **card** (a 32px-radius plate, 64px
inner padding). Allowed canvas→card combinations (`lib/themes.json` matrix):

| Canvas | Allowed cards |
|---|---|
| Teal `#029b77` | white, mint, image |
| Screen `#fafafa` | white, mint, teal, gray, image, black |
| Mint `#00d780` | white, mint, teal, gray, image, black |
| Black `#242424` | mint, white, gray, image |

White cards get the single allowed shadow (`0 8px 16px rgba(60,60,60,.10)`);
coloured cards never elevate.

## Logo — variant & placement

Four variants ship inlined. The renderer picks automatically from the **card**
surface the logo sits on (a logo is always on a card, never the bare canvas):

Logos are **black by default**. Exceptions: black/ink → green; teal → black (not
green); very dark image → assess per image and use green only if black is illegible.

| Card surface | Tone | Logo variant | Wordmark |
|---|---|---|---|
| white, mint, gray, **teal** | light | `primary` (black silhouette) | — |
| black, image | dark | `primary-green` (mint silhouette) | — |

- `mark-black` / `mark-green` (silhouette only, no wordmark) — only when space ≤ 92×64.
- On an image card, the variant assumes a **dark** placement area; override per slide with `"logo"` / `"textTone"` if the photo area is light. Assess contrast **per image** — never apply a blanket override.
- **Never place a logo inside a data container** (a metric / count-up card). The logo lives elsewhere in the deck.

### Placement & omission (`rules.json` → `logoRules`)
- **One logo per slide**, on the **primary card** (first content card). Optional — not every slide needs one.
- **Vertical:** the logo sits on the corner **opposite** the card's content. Content bottom-aligned → logo **top**; content top-aligned → logo **bottom**; centred content → logo top.
- **Horizontal:** the corner **nearest the slide's physical edge** — card in the left half → left, right half → right.
- **Omit the logo when:**
  - the slide shows a **table / graph / flow / diagram** (keep visual focus on the data),
  - the card is a **data / metric card** (count-up number) — never inside a data container,
  - the primary card content fills **≥ 50%** of the card height,
  - there is **no room** to place it without overlapping content.

## Centering content (`rules.json` → `centerRules`)

Centering both axes is the **exception**, reserved for content that *is* the message:
- a **metric** — a pure data point: heading (+ optional subheading), **no body, no image** (e.g. `€ 21,95` / `per maand`),
- a **quote**.

**Never centre** bulleted lists, titles with body copy, captions, or any multi-element block. Those stay left-aligned, bottom- or top-anchored.

## Tables (`rules.json` → `tableRules`)

- **Never scrollable.** If the data does not fit: split across slides, scale down, or omit. Overflow is a content problem, not a scroll problem.
- Header row: mint `#00d780`, black bold text.
- Body rows alternate **white** / **`#efefef`**.
- **Only the outer four corners** are rounded (16px) — not every cell.
- Column separators are **`#fafafa`** (screen colour) vertical lines.

## Voice (copy)

Dutch first, informal *"je"* (never *"u"*). Simpel, nuchter, menselijk — *aan de
keukentafel*. Titles 1–3 words. No emoji, no unicode icons, no marketing jargon,
no irony. Currency with comma decimal: `€ 21,95`.

## Labels (`rules.json` → `labelRules`)

The **label and the chip are the same component** (model field `label`; `chip` is
an exact alias). It sits above the heading with an **8px gap**.

**Colour by card surface** (resolved automatically from the card fill):

| Card surface | Label |
|---|---|
| White | green label, default (black) text |
| Teal | green label, default (black) text |
| Black | green label, black text on the label |
| Gray | green label |
| Mint green | **black** label, white text |
| Any other coloured surface (incl. green variants) | black label |

**Placement / when to use:**
- Labels appear **only when content is bottom-aligned**. When content is
  top-aligned, use a **subtitle** (`subheading`) instead.
- **Never on an image area / image card.**
- **Never** on the **first slide** of a deck, and **never** on an **opening slide**.
- **Never decorative** — only when the label adds information not already in the title.

## Bullet lists (`rules.json` → `signalRules`)

Bullet lists are allowed and should be **actively used**. Reach for a bullet list
whenever a slide contains a repeated-item list, a list of questions, or an
enumeration of items / options / steps. (Earlier guidance that avoided bullets is
superseded.) Bullets live in one card (max 5 × ~60 chars), Inter Regular, and stay
left-aligned — never centred.

## Data cards (`rules.json` → `dataCardRules`)

A card whose only content is a data metric (typically an animated count-up):
- The **number must be significantly larger than the caption**. The caption
  describes the metric (e.g. "churn increase") and is styled **small**.
- **No logo** inside a data container — it dilutes focus on the data.
- **Exactly 4 cards → always a 2×2 grid** (especially data cards). Never a single
  row of 4.

## Data sources (`rules.json` → `dataSourceRules`)

If a slide contains data (statistics, percentages, charts, numbers used as
evidence), its **source goes in the presenter notes** for that slide as a
`Source: …` line. If unknown, write `Source: unknown`.

After delivering the first version of a converted deck, prompt the user:
> "Some slides contain data. Can you provide the sources so I can add them to the
> presenter notes? If unavailable, I'll mark them as unknown."

If the user does not respond or cannot provide sources, leave `Source: unknown` —
**never block delivery** waiting for sources.

## Opening slides (`rules.json` → `openingSlideRules`)

Fixed structure (model: `"opening": true` + a `caption` object). **No labels.**
- **Title** — large, **dark green** (`#029b77`), **Inter**.
- **Subtitle** — large, Inter, regular weight.
- **Caption** — small, Inter, regular weight. Mandatory **three parts**:
  - `Author:` person or team name
  - `Date:` today's date — **restamped on every new iteration** (generate.mjs stamps it)
  - `Status:` planning / in progress / conclusions / direct report status — **mandatory**

## Photography

Warm everyday Dutch homes, natural light, people mid-action. Clipped to the
rounded **house silhouette** (`assets/house.svg`) on image cards. No b&w, no
duotone, no grain. (Photo inlining is deferred — see decision 4.)
