---
name: helix-slides
description: Generate, verify, and edit on-brand Budget Thuis (Dutch huismerk for energie, internet & mobiel) slide presentations using the Helix Design System. Use when the user wants to create a Budget Thuis deck/presentation/slides, check an existing deck for brand consistency, or edit a deck slide-by-slide. Produces a single self-contained standalone HTML file per presentation (no build step, opens anywhere). Internal use only.
user-invocable: true
metadata:
  website: BudgetThuis.Design/HelixSlides
  Author: Jairo in der Beeck
  version: "1.1"
  status: UserTesting
---

# Budget Thuis — Helix slide system

Three workflows over **one** shared model, asset library, and renderer. Every
presentation is a single self-contained HTML file: an embedded JSON slide model
(`<script id="deck-model">`) plus inlined CSS, fonts (base64 WOFF2), logos, and
a render function that builds the slides from the model.

Read `references/brand-tokens.md` for brand truth (colours, type, logo rules,
voice). The runtime reads colours/themes from `lib/themes.json`.

## Routing — pick the workflow from intent

| User wants | Workflow | Run |
|---|---|---|
| Make / build a new deck | **generate** | `node scripts/generate.mjs <model.json> [out.html]` |
| Check a deck is on-brand / in-bounds | **verify** | `node scripts/verify.mjs <deck.html>` |
| Change specific slides | **edit** | `node scripts/edit.mjs <deck.html> <instructions>` |

## How a deck is structured

- **Canvas** = backmost layer (the 32px ring colour). Content is **never**
  placed on the canvas directly.
- **Card** = 32px-radius plate (64px inner padding) that holds all content.
- **Theme** = a named, brand-derived canvas+card combination (`lib/themes.json`).
  Each slide is assigned one theme. The logo variant and text colour resolve
  automatically from the card surface.
- **Templates** (`slide.template`): `cover, title-image, title-card,
  section-mega, quote, bullets, table, grid-three, end-card`.

The slide model schema is `lib/deck-model.schema.json`. Authoring a deck = write
a model JSON (see `examples/`) and run `generate`.

## Generating a deck

1. Read `references/brand-tokens.md` and `lib/themes.json` for the brand truth,
   including the component rules (labels, bullets, data cards, data sources,
   gray usage, colour variety, logos, opening slides).
2. Write a model JSON conforming to `lib/deck-model.schema.json`. Pick a theme
   per slide from `themes.json` (do not invent colours). Open the deck with an
   `"opening": true` slide (title / subtitle / Author·Date·Status caption).
3. `node scripts/generate.mjs model.json deck.html`.
4. Verify before delivering: `node scripts/verify.mjs deck.html`.
5. **Data sources:** for any slide with data, put a `Source: …` line in the
   presenter notes (`Source: unknown` if not provided). After delivering the
   first version of a converted deck, prompt the user: *"Some slides contain
   data. Can you provide the sources so I can add them to the presenter notes?
   If unavailable, I'll mark them as unknown."* Don't block delivery on it.
6. Open `deck.html` to present (arrow keys navigate; `n` toggles presenter notes).

## Verifying a deck (Phase 3)

`node scripts/verify.mjs <deck.html> [--no-headless] [--json]` checks that the
deck follows **every** project rule and that nothing is broken. It reads the
deck's own embedded model/themes/rules, so it verifies exactly what renders.

- **Static pass** — canvas/card matrix, theme existence, broken asset refs, font
  usage, logo variant vs surface, labels, gray usage, 4-card 2×2, data sources,
  opening-slide structure, plus a content-fit heuristic.
- **Headless pass** — if `puppeteer` is installed, renders at 1920×1080 and
  measures real per-slide card/table overflow; otherwise skipped gracefully.

Exit code is non-zero on any **error**. Full rule/severity table:
`references/verifier.md`. Always run verify before delivering a deck.

## Files

```
SKILL.md
references/brand-tokens.md     brand truth + "what to use when"
references/verifier.md         Phase 3 verifier — rules checked + severities
lib/
  deck-model.schema.json       the embedded model schema
  themes.json                  surfaces, canvas→card matrix, logo/text rules, themes
  styles.css                   slide chrome (inlined into every deck)
  frame.html                   standalone shell skeleton
  render.js                    model → DOM renderer (shared by generate + edit)
  rules.json                   verifier rule table (Phase 3)
  _fonts.base64.json           subsetted WOFF2 data URIs (built by scripts/build-fonts.py)
assets/
  logos/*.svg                  4 brand logo variants (inlined)
  house.svg                    rounded-house image clip
scripts/
  assemble.mjs                 shared frame assembler
  generate.mjs                 model → standalone deck
  verify.mjs                   deck → rule + overflow report (Phase 3)
  edit.mjs                     deck + instructions → patched deck (Phase 4, planned)
  build-fonts.py               (re)build _fonts.base64.json from source fonts
examples/                      sample model + rendered deck
```

This skill is for internal Budget Thuis use. The embedded `Budget Greet Narrow`
font is proprietary — confirm licensing before sharing decks externally.
