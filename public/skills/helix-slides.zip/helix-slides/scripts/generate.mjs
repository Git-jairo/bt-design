#!/usr/bin/env node
/* generate.mjs — build a standalone Budget Thuis deck from a model JSON file.
 *
 *   node scripts/generate.mjs <model.json> [out.html]
 *
 * The model follows lib/deck-model.schema.json. Image assets may be supplied
 * inline (base64 in assets{}) or as { "src": "<path>", "mime": "..." } which
 * this script reads and base64-encodes. Output is fully self-contained.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { basename, extname, resolve } from "node:path";
import { assemble } from "./assemble.mjs";

const MIME = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".webp": "image/webp", ".gif": "image/gif", ".svg": "image/svg+xml" };

function inlineImages(model, baseDir) {
  if (!model.assets) return;
  for (const [id, a] of Object.entries(model.assets)) {
    if (a.data) continue;
    if (a.src) {
      const p = resolve(baseDir, a.src);
      a.data = readFileSync(p).toString("base64");
      a.mime = a.mime || MIME[extname(p).toLowerCase()] || "application/octet-stream";
      a.type = a.type || "image";
      delete a.src;
    }
  }
}

/* Opening-slide captions carry a date that must reflect THIS generation.
   Restamp caption.date to today on every build (QA: openingSlideRules). */
function stampOpeningDates(model) {
  const today = new Date().toISOString().slice(0, 10);
  for (const slide of model.slides || []) {
    if (slide.opening && slide.caption) slide.caption.date = today;
  }
}

function main() {
  const [modelPath, outArg] = process.argv.slice(2);
  if (!modelPath) {
    console.error("usage: node scripts/generate.mjs <model.json> [out.html]");
    process.exit(2);
  }
  const model = JSON.parse(readFileSync(modelPath, "utf8"));
  inlineImages(model, resolve(modelPath, ".."));
  stampOpeningDates(model);
  const html = assemble(model);
  const out = outArg || modelPath.replace(/\.json$/, "") + ".html";
  writeFileSync(out, html);
  const kb = Math.round(Buffer.byteLength(html) / 1024);
  console.error(`✓ ${basename(out)}  (${model.slides.length} slides, ${kb} KB, self-contained)`);
}

main();
