#!/usr/bin/env python3
"""Subset the brand fonts to a Latin/Dutch glyph set, convert to WOFF2, and
emit base64 data: URIs as lib/_fonts.base64.json.

This runs ONCE when packaging the skill (not when generating a deck). The
generated decks embed the base64 strings, so they stay self-contained with no
external font dependency. Re-run if the source fonts change.

Requires: fonttools, brotli  (pip install fonttools brotli)
"""
import base64
import json
import sys
from pathlib import Path
from fontTools.subset import Subsetter, Options
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT.parent / "_ref" / "budget-thuis-design" / "fonts"
OUT = ROOT / "lib" / "_fonts.base64.json"

# Latin + Dutch diacritics + smart punctuation + euro/bullet/ellipsis.
UNICODES = "U+0020-00FF,U+0100-017F,U+2013,U+2014,U+2018,U+2019,U+201C,U+201D,U+2022,U+2026,U+20AC,U+2212"

# family, weight, source file  -> the four Inter weights + Greet Bold.
FACES = [
    ("Inter", 400, "Inter-Regular.otf"),
    ("Inter", 500, "Inter-Medium.otf"),
    ("Inter", 600, "Inter-SemiBold.otf"),
    ("Inter", 700, "Inter-Bold.otf"),
    ("Budget Greet Narrow", 700, "BudgetGreetNarrow-Bold.otf"),
]


def subset_to_woff2_b64(path: Path) -> str:
    font = TTFont(path)
    opts = Options()
    opts.flavor = "woff2"
    opts.desubroutinize = True
    opts.layout_features = ["kern", "liga", "calt"]
    opts.name_IDs = []
    opts.notdef_outline = True
    opts.recalc_bounds = True
    sub = Subsetter(options=opts)
    sub.populate(unicodes=_parse_unicodes(UNICODES))
    sub.subset(font)
    import io
    buf = io.BytesIO()
    font.save(buf)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _parse_unicodes(spec: str):
    out = []
    for part in spec.split(","):
        part = part.strip().replace("U+", "")
        if "-" in part:
            a, b = part.split("-")
            out.extend(range(int(a, 16), int(b, 16) + 1))
        else:
            out.append(int(part, 16))
    return out


def main():
    if not SRC.exists():
        sys.exit(f"source fonts not found at {SRC}")
    faces = []
    total = 0
    for family, weight, fname in FACES:
        p = SRC / fname
        b64 = subset_to_woff2_b64(p)
        total += len(b64)
        faces.append({"family": family, "weight": weight, "format": "woff2", "b64": b64})
        print(f"  {fname:32} weight {weight}  ->  {len(b64)//1024} KB b64")
    OUT.write_text(json.dumps({"faces": faces}, indent=0))
    print(f"wrote {OUT}  ({total//1024} KB base64 total across {len(faces)} faces)")


if __name__ == "__main__":
    main()
