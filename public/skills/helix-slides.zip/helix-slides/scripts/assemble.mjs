/* Shared assembler: builds a standalone deck HTML from the frame parts + a
   deck model. Used by generate.mjs (new deck) and edit.mjs (re-render after
   patch). The output has zero external dependencies. */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const LIB = join(dirname(fileURLToPath(import.meta.url)), "..", "lib");
const ASSETS = join(dirname(fileURLToPath(import.meta.url)), "..", "assets");

const read = (p) => readFileSync(p, "utf8");

function fontFaces() {
  const { faces } = JSON.parse(read(join(LIB, "_fonts.base64.json")));
  return faces.map(f =>
    `@font-face{font-family:"${f.family}";font-weight:${f.weight};font-style:normal;` +
    `font-display:block;src:url("data:font/woff2;base64,${f.b64}") format("woff2");}`
  ).join("\n");
}

function logoLib() {
  const names = { "primary": "primary.svg", "primary-green": "primary-green.svg",
                  "mark-black": "mark-black.svg", "mark-green": "mark-green.svg" };
  const out = {};
  for (const [k, file] of Object.entries(names)) out[k] = read(join(ASSETS, "logos", file)).trim();
  return out;
}

function houseB64() {
  return Buffer.from(read(join(ASSETS, "house.svg")).trim(), "utf8").toString("base64");
}

/** Build a deck HTML string from a deck model object. */
export function assemble(model) {
  const meta = model.meta || {};
  const sub = {
    "{{LANG}}": meta.lang || "nl",
    "{{TITLE}}": (meta.title || "Budget Thuis").replace(/</g, "&lt;"),
    "/*__FONTS__*/": fontFaces(),
    "{{HOUSE_B64}}": houseB64(),
    "/*__STYLES__*/": read(join(LIB, "styles.css")),
    "{{THEME_CONFIG}}": read(join(LIB, "themes.json")),
    "{{LOGO_LIB}}": JSON.stringify(logoLib()),
    "{{SIGNAL_RULES}}": read(join(LIB, "rules.json")),
    "{{DECK_MODEL}}": JSON.stringify(model),
    "/*__RENDER__*/": read(join(LIB, "render.js")),
  };
  let html = read(join(LIB, "frame.html"));
  for (const [token, value] of Object.entries(sub)) {
    html = html.replace(token, () => value);   // function form: no $-pattern interpretation
  }
  return html;
}
