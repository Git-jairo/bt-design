#!/usr/bin/env node
/* verify.mjs — Phase 3 verifier for Budget Thuis / Helix decks.
 *
 *   node scripts/verify.mjs <deck.html> [--no-headless] [--json]
 *
 * Two passes:
 *   1. STATIC  — parses the embedded deck-model + theme-config + signal-rules
 *                and checks every project rule (canvas/card matrix, logo
 *                variant + tone, font usage, labels, gray usage, colour
 *                variety, data cards, data sources, opening slides, broken
 *                asset refs) plus a content-fit heuristic from rules.json.
 *   2. HEADLESS — if `puppeteer` is importable, renders the real deck at
 *                1920×1080 and measures actual card/table overflow per slide.
 *                Skipped gracefully (with an install hint) when unavailable.
 *
 * Exit code: 1 if any ERROR finding, else 0. (--json prints machine output.)
 *
 * Rule sources: references/brand-tokens.md, lib/themes.json, lib/rules.json.
 * Severities are documented in references/verifier.md.
 */
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

/* ── Findings collector ──────────────────────────────────────────── */
const findings = [];
function add(severity, slide, rule, message) {
  findings.push({ severity, slide, rule, message });
}
const ERROR = "error", WARN = "warn", INFO = "info";

/* ── Embedded-JSON extraction ────────────────────────────────────── */
function extractJSON(html, id) {
  const re = new RegExp('<script[^>]*id="' + id + '"[^>]*>([\\s\\S]*?)</script>');
  const m = html.match(re);
  if (!m) return null;
  try { return JSON.parse(m[1]); } catch { return undefined; }
}

/* ── Layout mirror (kept in sync with lib/render.js) ─────────────── */
function detectSignals(slide) {
  return {
    hasData:  !!slide.data,
    hasImage: !!slide.image,
    hasMain:  !!(slide.heading || slide.body || slide.bullets || slide.quote),
    itemCount: Array.isArray(slide.items) ? slide.items.length : 0,
  };
}
function resolveLayout(slide, rules) {
  if (slide.layout === "fullscreen") return "fullscreen";
  if (slide.layout && typeof slide.layout === "object") return slide.layout;
  const sig = detectSignals(slide);
  const sorted = (rules.signalRules || []).slice().sort((a, b) => (b.priority || 0) - (a.priority || 0));
  for (const r of sorted) {
    const t = r.trigger; let ok = true;
    if (t.hasData   !== undefined && sig.hasData   !== t.hasData)   ok = false;
    if (t.hasImage  !== undefined && sig.hasImage  !== t.hasImage)  ok = false;
    if (t.hasMain   !== undefined && sig.hasMain   !== t.hasMain)   ok = false;
    if (t.itemCount !== undefined && sig.itemCount !== t.itemCount) ok = false;
    if (ok) return r.layout;
  }
  return { columns: [1] };
}
function normCols(layout) {
  if (typeof layout === "string") return null; // fullscreen
  return (layout.columns || [1]).map((c) =>
    typeof c === "number" ? { weight: c, rows: 1 }
                          : { weight: c.weight || 1, rows: Math.min(3, Math.max(1, c.rows || 1)) });
}
function isMetric(it) {
  return !!(it && (it.heading || it.subheading) && !it.body && !it.image);
}

/* ── STATIC CHECKS ───────────────────────────────────────────────── */
function staticChecks(model, themes, rules) {
  if (!model)            { add(ERROR, 0, "model", "No deck-model found / unparseable in the deck."); return; }
  if (model === undefined) { add(ERROR, 0, "model", "deck-model JSON failed to parse."); return; }
  if (!Array.isArray(model.slides) || !model.slides.length) {
    add(ERROR, 0, "model", "Deck has no slides."); return;
  }
  if (!themes || !themes.themes) { add(ERROR, 0, "themes", "theme-config missing — cannot validate surfaces."); }
  if (!rules)  { add(WARN, 0, "rules", "signal-rules missing — layout checks limited."); rules = { signalRules: [] }; }

  const tone     = (themes && themes.tone) || {};
  const matrix   = (themes && themes.matrix) || {};
  const themeMap = (themes && themes.themes) || {};
  const fitting  = (rules && rules.contentFitting) || {};
  const assets   = model.assets || {};

  const seenIds = new Set();

  model.slides.forEach((slide, idx) => {
    const n = idx + 1;
    const sig = detectSignals(slide);

    /* structural / "nothing broken" */
    if (!slide.id)    add(ERROR, n, "schema", "Slide is missing an 'id'.");
    if (slide.id && seenIds.has(slide.id)) add(WARN, n, "schema", `Duplicate slide id '${slide.id}'.`);
    if (slide.id) seenIds.add(slide.id);
    if (!slide.theme) add(ERROR, n, "schema", "Slide is missing a 'theme'.");

    const theme  = themeMap[slide.theme];
    if (slide.theme && !theme) {
      add(ERROR, n, "theme-exists", `Unknown theme '${slide.theme}' (not in themes.json).`);
    }
    const canvas = theme && theme.canvas;
    const card   = theme && theme.card;

    /* canvas/card matrix */
    if (canvas && card && matrix[canvas] && !matrix[canvas].includes(card)) {
      add(ERROR, n, "canvas-card-combo", `Card '${card}' is not allowed on canvas '${canvas}'.`);
    }
    /* per-item theme overrides must satisfy the matrix on the slide canvas */
    (slide.items || []).forEach((it, ii) => {
      if (!it.theme) return;
      const t = themeMap[it.theme];
      if (!t) { add(ERROR, n, "theme-exists", `Item ${ii + 1}: unknown theme '${it.theme}'.`); return; }
      if (canvas && matrix[canvas] && !matrix[canvas].includes(t.card)) {
        add(ERROR, n, "canvas-card-combo", `Item ${ii + 1}: card '${t.card}' not allowed on slide canvas '${canvas}'.`);
      }
    });

    /* broken asset refs */
    const refs = [];
    if (slide.image && slide.image.ref) refs.push(slide.image.ref);
    (slide.items || []).forEach((it) => { if (it.image && it.image.ref) refs.push(it.image.ref); });
    refs.forEach((ref) => {
      if (!assets[ref]) add(ERROR, n, "asset-ref", `Image ref '${ref}' has no matching entry in assets{}.`);
    });

    /* logo variant + tone */
    const LOGO_ENUM = ["auto", "primary", "primary-green", "mark-black", "mark-green", "none"];
    if (slide.logo && !LOGO_ENUM.includes(slide.logo)) {
      add(ERROR, n, "logo-variant", `Invalid logo '${slide.logo}'.`);
    } else if (slide.logo && !["auto", "none"].includes(slide.logo) && !slide.logo.startsWith("mark") && card) {
      const expected = (tone[card] === "dark") ? "primary-green" : "primary";
      if (slide.logo !== expected && card !== "image") {
        add(WARN, n, "logo-variant",
          `Logo '${slide.logo}' contradicts the ${card} surface (expected '${expected}': black on light/teal, green on black). Only image cards may flip per-image.`);
      }
    }

    /* labels (label === chip) */
    const label = slide.label || slide.chip;
    if (label) {
      if (n === 1)         add(ERROR, n, "label-placement", "Label on the first slide of the deck (not allowed).");
      if (slide.opening)   add(ERROR, n, "label-placement", "Label on an opening slide (not allowed).");
      if (card === "image" || (sig.hasImage && !sig.hasMain))
                           add(WARN,  n, "label-placement", "Label on an image area (labels are never used on image cards).");
      if (slide.quote)     add(WARN,  n, "label-placement", "Label with a quote (centered content) — use a subtitle instead.");
      if (sig.hasData)     add(WARN,  n, "label-placement", "Label on a data slide (top/flush content) — use a subtitle instead.");
      if (sig.itemCount > 0 && !sig.hasMain)
                           add(WARN,  n, "label-placement", "Label on an items-only slide (top-aligned) — it will not render; use a subtitle.");
    }

    /* gray usage — never a standalone full-width main card */
    if (card === "gray") {
      const layout = resolveLayout(slide, rules);
      const cols = normCols(layout);
      const standalone = layout === "fullscreen" || (cols && cols.length === 1 && (cols[0].rows || 1) === 1);
      if (standalone) {
        add(ERROR, n, "gray-usage", "Gray is used as a standalone full-width card. Gray is secondary only — use it as a column/row beside other elements.");
      }
    }

    /* 4 cards must be 2x2 (only manual single-row overrides reach here) */
    if (sig.itemCount === 4 && slide.layout && typeof slide.layout === "object") {
      const cols = normCols(slide.layout);
      const singleRow = cols.length === 4 && cols.every((c) => (c.rows || 1) === 1);
      if (singleRow) add(WARN, n, "data-cards-2x2", "4 cards are laid out in a single row — use a 2x2 grid instead.");
    }

    /* data sources in presenter notes */
    const anyMetric = Array.isArray(slide.items) && slide.items.some(isMetric);
    const notes = slide.presenter || "";
    const hasSource = /source\s*:/i.test(notes);
    if (sig.hasData && !hasSource) {
      add(WARN, n, "data-source", "Data slide has no 'Source:' line in presenter notes (use 'Source: unknown' if not provided).");
    } else if (!sig.hasData && anyMetric && !hasSource) {
      add(INFO, n, "data-source", "Slide shows metric numbers — consider adding a 'Source:' line to presenter notes.");
    }

    /* opening slide structure */
    if (slide.opening) {
      const cap = slide.caption;
      if (!cap) {
        add(ERROR, n, "opening-slide", "Opening slide has no caption (Author / Date / Status required).");
      } else {
        if (!cap.status) add(ERROR, n, "opening-slide", "Opening caption is missing the mandatory 'Status'.");
        if (!cap.author) add(WARN,  n, "opening-slide", "Opening caption is missing 'Author'.");
        /* date is auto-stamped by generate.mjs; absence is fine */
      }
    }

    /* content-fit heuristic (uses rules.json contentFitting) */
    if (fitting.basePadding) overflowHeuristic(slide, sig, rules, fitting, n);
  });
}

/* Estimate content height for a card descriptor using the project's own
   per-element heights (rules.json contentFitting). Approximate — flagged as
   heuristic; the headless pass measures the truth. */
function estimateHeight(d, fitting) {
  let h = fitting.basePadding || 128;
  if (d.chip)       h += (fitting.chip || 60) + 8;
  if (d.heading)    h += fitting.heading || 120;
  if (d.subheading) h += fitting.subheading || 80;
  if (d.quote)      h += (fitting.heading || 120) + 40;
  if (Array.isArray(d.bullets) && d.bullets.length) h += (fitting.gap || 48) + d.bullets.length * (fitting.bullet || 64);
  if (d.body) { const lines = Math.max(1, Math.ceil(d.body.length / 45)); h += (fitting.gap || 48) + lines * (fitting.bodyLine || 64); }
  return h;
}
function availableForCard(rows) {
  return (952 - 64 * (rows - 1)) / rows;  /* canvas inner height split across a column's rows */
}
function overflowHeuristic(slide, sig, rules, fitting, n) {
  const layout = resolveLayout(slide, rules);
  if (layout === "fullscreen") return;       /* data tables checked at runtime / headless */
  const cols = normCols(layout);

  cols.forEach((col, colIdx) => {
    /* mirror of getCardDescriptors for the dense (text) card slots */
    let descriptors = [];
    if (sig.itemCount > 0 && !sig.hasMain) {
      let start = 0; for (let c = 0; c < colIdx; c++) start += cols[c].rows || 1;
      for (let r = 0; r < (col.rows || 1); r++) descriptors.push(slide.items[start + r] || {});
    } else if (sig.itemCount > 0 && sig.hasMain) {
      if (colIdx === 0) descriptors = [{ heading: slide.heading, subheading: slide.subheading, bullets: slide.bullets, body: slide.body, chip: slide.label || slide.chip }];
      else for (let r = 0; r < (col.rows || 1); r++) descriptors.push(slide.items[r] || {});
    } else if (sig.hasImage) {
      const placement = (slide.image && slide.image.placement) || "right";
      const isImageCol = (placement === "right" && colIdx === cols.length - 1) || (placement === "left" && colIdx === 0);
      descriptors = isImageCol ? [{}] : [{ heading: slide.heading, subheading: slide.subheading, bullets: slide.bullets, body: slide.body, chip: slide.label || slide.chip }];
    } else {
      descriptors = [{ heading: slide.heading, subheading: slide.subheading, bullets: slide.bullets, body: slide.body, quote: slide.quote, chip: slide.label || slide.chip }];
    }

    const avail = availableForCard(col.rows || 1);
    descriptors.forEach((d) => {
      const est = estimateHeight(d, fitting);
      if (est > avail * 1.05) {
        add(WARN, n, "overflow-heuristic",
          `Estimated content (~${Math.round(est)}px) likely exceeds the card (~${Math.round(avail)}px). Heuristic — run with puppeteer for exact overflow.`);
      }
    });
  });
}

/* ── HEADLESS OVERFLOW SCAN (puppeteer, optional) ────────────────── */
async function headlessChecks(htmlPath) {
  let puppeteer;
  try { puppeteer = (await import("puppeteer")).default; }
  catch {
    add(INFO, 0, "headless", "Headless overflow scan skipped — puppeteer not installed. Enable with: npm i -D puppeteer");
    return;
  }
  let browser;
  try {
    browser = await puppeteer.launch({ headless: "new" });
    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
    await page.goto("file://" + resolve(htmlPath), { waitUntil: "networkidle0" });
    const count = await page.evaluate(() => (window.__DECK__ ? window.__DECK__.count() : 0));
    if (!count) { add(WARN, 0, "headless", "Renderer exposed no slides (window.__DECK__ empty)."); return; }

    for (let i = 0; i < count; i++) {
      await page.evaluate((idx) => window.__DECK__.show(idx), i);
      await new Promise((r) => setTimeout(r, 30));
      const issues = await page.evaluate(() => {
        const slide = document.querySelector(".slide.is-active");
        if (!slide) return [];
        const out = [];
        slide.querySelectorAll(".card").forEach((cardEl, ci) => {
          const cs = getComputedStyle(cardEl);
          const padV = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
          const avail = cardEl.clientHeight - padV;
          const content = cardEl.querySelector(".content");
          if (content && content.scrollHeight > avail + 1) {
            out.push(`card ${ci + 1}: content ${content.scrollHeight}px > available ${Math.round(avail)}px`);
          }
          const table = cardEl.querySelector(".data-table-wrap");
          if (table && table.getBoundingClientRect) {
            const cardBottom = cardEl.getBoundingClientRect().bottom - parseFloat(cs.paddingBottom);
            if (table.getBoundingClientRect().bottom > cardBottom + 1) out.push(`card ${ci + 1}: table overflows the card`);
          }
        });
        return out;
      });
      issues.forEach((msg) => add(WARN, i + 1, "overflow", msg));
    }
  } catch (e) {
    add(WARN, 0, "headless", "Headless scan failed: " + (e && e.message ? e.message : String(e)));
  } finally {
    if (browser) await browser.close();
  }
}

/* ── Report ──────────────────────────────────────────────────────── */
function report(jsonMode) {
  const counts = { error: 0, warn: 0, info: 0 };
  findings.forEach((f) => { counts[f.severity]++; });

  if (jsonMode) {
    process.stdout.write(JSON.stringify({ counts, findings }, null, 2) + "\n");
    return counts.error > 0 ? 1 : 0;
  }

  const ICON = { error: "✗", warn: "▲", info: "·" };
  if (!findings.length) {
    console.log("✓ No issues found. Deck follows all project rules.");
  } else {
    const order = { error: 0, warn: 1, info: 2 };
    findings.sort((a, b) => order[a.severity] - order[b.severity] || a.slide - b.slide);
    for (const f of findings) {
      const where = f.slide ? `slide ${f.slide}` : "deck";
      console.log(`${ICON[f.severity]} [${f.severity}] ${where} · ${f.rule}: ${f.message}`);
    }
  }
  console.log(`\n${counts.error} error(s), ${counts.warn} warning(s), ${counts.info} info.`);
  return counts.error > 0 ? 1 : 0;
}

/* ── Main ────────────────────────────────────────────────────────── */
async function main() {
  const args = process.argv.slice(2);
  const deckPath = args.find((a) => !a.startsWith("--"));
  const noHeadless = args.includes("--no-headless");
  const jsonMode = args.includes("--json");
  if (!deckPath) {
    console.error("usage: node scripts/verify.mjs <deck.html> [--no-headless] [--json]");
    process.exit(2);
  }

  let html;
  try { html = readFileSync(deckPath, "utf8"); }
  catch { console.error(`Cannot read ${deckPath}`); process.exit(2); }

  const model  = extractJSON(html, "deck-model");
  const themes = extractJSON(html, "theme-config");
  const rules  = extractJSON(html, "signal-rules") || { signalRules: [] };

  /* font usage — both brand families must be embedded; flag any stray family */
  fontChecks(html);

  staticChecks(model, themes, rules);
  if (!noHeadless) await headlessChecks(deckPath);

  process.exit(report(jsonMode));
}

function fontChecks(html) {
  const families = new Set();
  const faceRe = /font-family\s*:\s*([^;{}]+)/gi;
  let m;
  while ((m = faceRe.exec(html))) {
    m[1].split(",").forEach((f) => families.add(f.trim().replace(/^["']|["']$/g, "").toLowerCase()));
  }
  const ALLOWED = new Set([
    "inter", "budget greet narrow", "barlow condensed", "impact",
    "-apple-system", "blinkmacsystemfont", "segoe ui", "system-ui", "sans-serif", "var(--font-body)", "var(--font-display)",
  ]);
  if (!families.has("inter"))               add(ERROR, 0, "font-usage", "Inter @font-face not found — body font missing.");
  if (!families.has("budget greet narrow")) add(ERROR, 0, "font-usage", "Budget Greet Narrow @font-face not found — display font missing.");
  for (const fam of families) {
    if (!fam || fam.startsWith("var(")) continue;
    if (!ALLOWED.has(fam)) add(WARN, 0, "font-usage", `Unexpected font family '${fam}' (only Inter + Budget Greet Narrow, no serif/mono).`);
  }
}

main();
