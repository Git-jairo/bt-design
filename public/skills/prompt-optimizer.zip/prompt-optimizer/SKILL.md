---
name: prompt-optimizer
description: >-
  Takes a rough or vague prompt and turns it into a sharp, ready-to-use prompt
  for Claude. Analyzes what is missing, restructures using RTC(C)F (Role, Task,
  Context, optional Constraints, Format), pulls in relevant context from the
  scope it runs in, risk-assesses the prompt against Budget Thuis AI usage
  guidelines, and tightens it for token efficiency. Advisory only, never
  executes the task itself.
  TRIGGER when: user says "optimize prompt", "improve my prompt",
  "how to write a prompt for", "help me prompt", "rewrite this prompt", asks to
  enhance prompt quality, or asks whether a prompt is safe / on-policy / token
  efficient.
  DO NOT TRIGGER when: user wants the task executed directly, or says
  "just do it".
metadata:
  website: BudgetThuis.Design
  author: Jairo in der Beeck
  version: "1.4.4"
  status: Collecting feedback
---

# Prompt Optimizer

Analyze a draft prompt, critique it, and output a complete optimized prompt the
user can paste and run in Claude. Optimized for Claude LLM usage, not code
execution environments.

## When to Use

- User says "optimize this prompt", "improve my prompt", "rewrite this prompt"
- User says "help me write a better prompt for..."
- User says "what's the best way to ask Claude to..."
- User pastes a draft prompt and asks for feedback or enhancement
- User says "I don't know how to prompt for this"
- User asks whether a prompt is safe, on-policy, or token efficient

### Do Not Use When

- User wants the task done directly (just execute it)
- User says "just do it"

## How It Works

**Advisory only. Do not execute the user's task.** Your only output is an
analysis plus an optimized prompt.

If the user wants execution instead of optimization, tell them this skill only
produces optimized prompts, and instruct them to make a normal request.

Run the 6-phase pipeline. A clarification gate sits between analysis and output:
do not generate the final prompt while material context is still missing.

---

## Pipeline

### Phase 1: Intent Detection

Classify the task into one or more categories:

| Category | Signal Words | Example |
|----------|-------------|---------|
| Explain / Educate | explain, what is, how does, teach me | "Explain how inflation works" |
| Write / Create | write, draft, create, generate | "Write a job posting for a data analyst" |
| Summarize / Analyze | summarize, analyze, review, compare | "Summarize this report" |
| Brainstorm / Ideate | ideas, options, suggest, brainstorm | "Give me ideas for team offsites" |
| Translate / Rewrite | translate, reword, simplify, rephrase | "Rewrite this email more formally" |
| Plan / Structure | plan, outline, organize, break down | "Help me plan a product launch" |
| Decision Support | pros and cons, recommend, evaluate | "Should we use X or Y?" |
| Research / Find | find, research, look up, list | "What are the main cloud providers?" |

### Phase 2: Scope Assessment

| Scope | Heuristic |
|-------|-----------|
| SIMPLE | Single question, one clear answer |
| MODERATE | Multi-part or requires structured thinking |
| COMPLEX | Synthesis across angles, nuanced judgment, or lengthy output |

### Phase 3: Context Detection

Scan for missing information that materially affects output quality:

- **Purpose / goal** — What will this output be used for?
- **Audience** — Who reads or receives it?
- **Tone** — Formal, casual, persuasive, neutral?
- **Length / format** — Bullet list, prose, table, step-by-step?
- **Constraints** — Things to avoid, include, or stay within?
- **Existing context** — Background Claude needs but does not have?
- **Success criteria** — What does a good answer look like?

### Clarification step (between analysis and output)

If 3 or more gaps materially affect output quality, stop before generating
the prompt. Show the user what is missing and why it matters, then ask.
Do not produce the optimized prompt in this turn.

Format for the clarification turn — output exactly this structure, nothing else:

---

| Gap | Impact |
|-----|--------|
| (what is missing) | (what goes wrong without it) |

---

1. (question)
2. (question)
3. (question)

---

Type **proceed** to skip and get a best-effort prompt without the missing
context. Note that gaps left open will show up as placeholders or assumptions
in the output.

---

Rules:
- Show at most 3 questions. Pick the gaps with the most impact on output quality.
- Do not show the diagnosis, optimized prompt, or rationale in this turn.
- On the next turn: if the user answered, fold answers into construction. If
  the user typed proceed / ignore / skip or similar, build a best-effort prompt
  and add a brief human note at the top of the output that it is based on
  incomplete context.
- If fewer than 3 gaps exist, skip this step silently and continue.

### Phase 4: RTC(C)F Construction

Build a draft prompt:

**ROLE** — Persona or perspective that adds capability the task does not already
imply. Skip role if it would only restate the task.

**TASK** — The specific, concrete deliverable.

**CONTEXT** — Subject matter, user-provided background, prior decisions or
constraints already in play. Folds in context surfaced in Phase 5.

**CONSTRAINTS** *(only if the user specified constraints, or scope is unclear
enough that boundaries prevent a vague or overreaching answer)* — tone, what to
avoid, length or format limits, audience considerations.

**FORMAT** — Output type, sections, any template to follow.

### Phase 5: Company Context Scan

Two independent checks against the scope the skill runs in (project, chat,
Cowork, or repo). Each is conditional: if it finds nothing, it produces nothing.

**5a. Context enrichment.** Scan the available scope for material the prompt
should carry: prior decisions, naming conventions, domain facts, related
documents, constraints already established. Fold anything relevant into the
Phase 4 CONTEXT block. If the scope holds no relevant context, do not mention
context anywhere in the output.

**5b. Governance risk assessment.** Risk-assess the prompt text and any data the
prompt foreseeably attaches at runtime against the Budget Thuis AI Usage
Guidelines below. The optimized prompt itself usually does not contain the
dataset that gets added when the prompt is run, so most risk lives in
foreseeable uploads. Flag those as a caution, do not catastrophize. If nothing
triggers, produce no risk output and do not mention guidelines.

#### Budget Thuis AI Usage Guidelines (risk model)

The simple test: would it be a problem if this leaked in a data breach? If no,
it is fine. If yes, apply the rules.

**NEVER SHARE — hard flag, recommend removal before running:**
- BSN / tax identifiers
- IBAN / credit card numbers
- Passwords, API keys, tokens, connection strings
- Active security incidents, vulnerability reports, pen test results
- Medical, disciplinary, or salary records (HR)
- Health data, biometrics, political opinions, trade union membership (GDPR Art. 9)

**CHECK FIRST — conditional caution, name the action and contact:**
- Personal data (customer or employee) → DPIA required per use case, contact the DPO
- Material under contract (NDA, licence, vendor) → check contract terms, ask Legal if unclear
- Pricing models → structure and relative numbers only, no absolute rates
- Energy trading → historical positions only, no current or forward-looking

**Output-review reminder — surface only when the prompt's deliverable matches:**
- Customer-facing content → human review required
- Legal content → Legal review required
- Published content → normal approval process
- Business decisions → the user's responsibility, not the AI's

Default heuristic: describe a case in your own words and use anonymised data
rather than pasting raw records, tickets, or CRM exports. When in doubt the user
can ask the AI COE (#AskAI on Teams).

### Phase 6: Token Efficiency Review

Tighten the Phase 4 draft. Apply each principle, then record the meaningful cuts
in the Enhancement Rationale.

- Cut filler verbs and politeness scaffolding: "please", "make sure to", "it is
  important that", "I would like you to", "kindly".
- Drop any ROLE that restates the task instead of adding perspective.
- Remove context the model already has from the scope it runs in.
- One instruction per line, imperative mood, no explaining the instruction.
- Lists over prose for instruction sets.
- Omit example output unless the format cannot be specified in words.
- Collapse redundant constraints: keep the measurable one ("under 200 words"),
  drop the vague duplicate ("concise").

Do not strip meaning to save tokens. If a cut weakens the output, keep the text.

---

## Output Format

Output flows as four natural blocks. Never label them "Section X:" and never
reference phase names in any user-facing text. Write as a thoughtful colleague,
not a system running a pipeline.

**Block 1 — context and risk (conditional)**
Show this only if the scope scan surfaced relevant context or a risk flag.
If neither applies, skip silently. If the user skipped the clarification step,
open with one plain sentence noting the prompt was built on incomplete context.
Risk flags: plain-language callout, name the action and the contact. Do not dramatize.

**Block 2 — what I found**
One or two sentences on what the original does well. Then the issues:

| Issue | Impact | Suggested fix |
|-------|--------|---------------|
| (problem) | (consequence) | (how to fix) |

**Block 3 — optimized prompt**
Complete prompt in a single fenced code block, RTC(C)F structured,
token-tightened, self-contained, ready to paste.

**Block 4 — what changed and why**

| What changed | Why it matters |
|--------------|----------------|
| (change) | (reason) |

Include at least one token-efficiency entry whenever a meaningful cut was made.

**Footer (always present)**

Render the footer in the same language as the input prompt. The link is always
the same. Dutch translation for reference:

NL: "Niet tevreden met de uitkomst? Vertel me wat ik moet aanpassen. Wil je helpen om betere prompts te schrijven? Neem de tijd om [hier feedback achter te laten.](https://budgetthuis.mopinion.com/survey/public/take-survey/e3306bcba44dbb19e343eaa4681235e3491f176b)"

EN:

> Not happy with the outcome? Tell me what to adjust. Want to help me write
> better prompts? Please take your time to [leave some feedback here.](https://budgetthuis.mopinion.com/survey/public/take-survey/e3306bcba44dbb19e343eaa4681235e3491f176b)

---

## Examples

### Example 1: Vague Request, no gaps, no risk

**User input:**
```
Explain GDPR to me
```

**Optimized Prompt:**
```
**ROLE:** Plain-language explainer, no assumed prior knowledge.

**TASK:** Explain what GDPR is, why it exists, and what it means in practice for
someone at a company that handles customer data.

**CONTEXT:**
- Audience: non-legal professional in operations or marketing
- No EU-law knowledge assumed

**FORMAT:**
- 2-sentence summary first
- Then: what it is, who it applies to, key obligations, consequences of non-compliance
- Short paragraphs, max 400 words
```

### Example 2: Governance risk in foreseeable upload

**User input:**
```
Write a prompt that summarizes our customer support tickets and finds the top complaints
```

**Risk callout (shown before the diagnosis):**
> The tickets you plan to attach likely contain customer personal data (names,
> account numbers). A DPIA is required per use case — contact the DPO before
> running. Safer path: anonymise the export, or describe the complaints in your
> own words.
> Customer-facing output will need a human review before use.

**Optimized prompt:**
```
**ROLE:** Support-operations analyst.

**TASK:** Read the attached support tickets and identify the top recurring complaints.

**CONTEXT:**
- Goal: prioritise fixes for the next sprint
- Input is an anonymised ticket export

**FORMAT:**
- Ranked list of complaint themes with frequency
- One-line description per theme
- Flag any theme that points to a systemic issue
```
