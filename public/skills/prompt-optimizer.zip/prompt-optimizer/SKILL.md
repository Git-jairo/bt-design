---
name: prompt-optimizer
description: >-
  Takes a rough or vague prompt and turns it into a sharp, ready-to-use prompt
  for Claude. Analyzes what is missing, then restructures the prompt using the
  RTC(C)F format: Role (what perspective Claude should take), Task (the concrete
  deliverable), Context (background Claude needs to know), Constraints (scope
  boundaries, only when needed), and Format (how the output should be structured).
  Advisory only, never executes the task itself.
  TRIGGER when: user says "optimize prompt", "improve my prompt",
  "how to write a prompt for", "help me prompt", "rewrite this prompt",
  or explicitly asks to enhance prompt quality.
  DO NOT TRIGGER when: user wants the task executed directly, or says
  "just do it".
metadata:
  author: Jairo
  version: "1.3.2"
---

# Prompt Optimizer

Analyze a draft prompt, critique it, and output a complete optimized prompt
the user can paste and run in Claude chat. Optimized for Claude LLM usage,
not code execution environments.

## When to Use

- User says "optimize this prompt", "improve my prompt", "rewrite this prompt"
- User says "help me write a better prompt for..."
- User says "what's the best way to ask Claude to..."
- User pastes a draft prompt and asks for feedback or enhancement
- User says "I don't know how to prompt for this"

### Do Not Use When

- User wants the task done directly (just execute it)
- User says "just do it"

## How It Works

**Advisory only — do not execute the user's task.**

Your ONLY output is an analysis plus an optimized prompt.

If the user says "just do it" or wants execution instead of optimization,
tell them this skill only produces optimized prompts, and instruct them to
make a normal request if they want execution instead.

Run this 4-phase pipeline sequentially. Present results using the Output
Format below.

---

### Phase 1: Intent Detection

Classify the user's task into one or more categories:

| Category | Signal Words | Example |
|----------|-------------|---------|
| Explain / Educate | explain, what is, how does, teach me | "Explain how inflation works" |
| Write / Create | write, draft, create, generate | "Write a job posting for a data analyst" |
| Summarize / Analyze | summarize, analyze, review, compare | "Summarize this report" |
| Brainstorm / Ideate | ideas, options, suggest, brainstorm | "Give me ideas for team offsites" |
| Translate / Rewrite | translate, reword, simplify, rephrase | "Rewrite this email more formally" |
| Plan / Structure | plan, outline, organize, break down | "Help me plan a product launch" |
| Decision Support | pros and cons, recommend, evaluate | "Should we use X or Y?" |
| Research / Find | find, research, look up, list | "What are the main cloud providers?" |

### Phase 2: Scope Assessment

Estimate complexity from the prompt alone:

| Scope | Heuristic |
|-------|-----------|
| SIMPLE | Single question, one clear answer |
| MODERATE | Multi-part or requires structured thinking |
| COMPLEX | Requires synthesis across multiple angles, nuanced judgment, or lengthy output |

### Phase 3: Context Detection

Scan the prompt for missing information that would improve Claude's output.
Ask about whichever of these are absent and materially affect the answer:

- **Purpose / goal** — What will this output be used for?
- **Audience** — Who will read or receive the output?
- **Tone** — Formal, casual, persuasive, neutral?
- **Length / format** — Bullet list, prose, table, step-by-step?
- **Constraints** — Things to avoid, include, or stay within?
- **Existing context** — Background the user hasn't shared but Claude would need?
- **Success criteria** — What does a good answer look like?

If 3+ items are missing and materially affect output quality, ask up to 3
clarification questions before generating the optimized prompt.

### Phase 4: RTC(C)F Prompt Construction

Build the optimized prompt using RTC(C)F structure:

**ROLE:** The persona or perspective Claude should take
(e.g., "experienced HR manager", "neutral policy analyst", "plain-language editor")

**TASK:** The specific, concrete action or deliverable
(e.g., "Write a 3-paragraph summary", "List 5 pros and 5 cons", "Draft a formal response")

**CONTEXT:** Background information Claude needs, including:
- Subject matter or domain
- Relevant background the user has provided
- Any prior decisions or constraints already in play

**CONSTRAINTS:** *(only include if the user specified constraints, or if scope is unclear enough that boundaries are needed to prevent a vague or overreaching answer)*
- Tone, register, or style requirements
- What to avoid or exclude
- Length or format limits
- Audience-specific considerations

**FORMAT:** How to structure the output, including:
- Output type (bullet list, numbered steps, prose, table, etc.)
- Sections or headings expected
- Any examples or templates to follow

---

## Output Format

### Section 1: Prompt Diagnosis

**Strengths:** What the original prompt does well.

**Issues:**

| Issue | Impact | Suggested Fix |
|-------|--------|---------------|
| (problem) | (consequence) | (how to fix) |

**Needs Clarification:** Questions the user should answer before running the
prompt. Only include if answers are genuinely missing and affect output quality.

### Section 2: Optimized Prompt

Present the complete optimized prompt inside a single fenced code block using
RTC(C)F format. Must be self-contained and ready to copy-paste into Claude chat.

```
**ROLE:** ...

**TASK:** ...

**CONTEXT:**
- ...

**CONSTRAINTS:** *(omit if none apply and scope is clear)*
- ...

**FORMAT:**
- ...
```

### Section 3: Enhancement Rationale

Brief table explaining what was added or changed and why.

| Enhancement | Reason |
|-------------|--------|
| (what was added) | (why it matters) |

### Footer

> Not what you need? Tell me what to adjust, or just make a normal request
> if you want execution instead of prompt optimization.

---

## Examples

### Example 1: Vague Request

**User input:**
```
Explain GDPR to me
```

**Optimized Prompt:**
```
**ROLE:** Plain-language explainer with no assumed prior knowledge.

**TASK:** Explain what GDPR is, why it exists, and what it means in practice
for someone working at a company that handles customer data.

**CONTEXT:**
- Audience: Non-legal professional, works in operations or marketing
- No prior knowledge of EU law assumed

**FORMAT:**
- Start with a 2-sentence summary
- Then cover: what it is, who it applies to, key obligations, consequences of non-compliance
- Use short paragraphs, not bullet overload
- Max 400 words
```

---

### Example 2: Moderate Request

**User input:**
```
Help me write an email to a client about a delay in their project
```

**Optimized Prompt:**
```
**ROLE:** Senior account manager known for clear, empathetic client communication.

**TASK:** Draft a professional email to a client informing them of a 2-week
delay in their project delivery, explaining the reason briefly and proposing
a revised timeline.

**CONTEXT:**
- Client relationship: ongoing, professional, no prior major issues
- Reason for delay: dependency on a third-party supplier (non-negotiable)
- New expected delivery: 2 weeks from original date

**CONSTRAINTS:**
- Do not over-apologize or sound defensive
- Do not promise things that may not be deliverable
- Keep it concise, under 200 words
- Tone: professional and direct, with empathy

**FORMAT:**
- Subject line
- Opening: acknowledge the situation
- Body: brief explanation, revised timeline, what we are doing to mitigate
- Closing: invite questions, reaffirm commitment
```
